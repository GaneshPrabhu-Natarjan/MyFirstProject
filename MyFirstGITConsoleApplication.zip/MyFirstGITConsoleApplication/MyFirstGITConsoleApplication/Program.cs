﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstGITConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("You are Landed on the GIT hub.");
            Console.ReadLine();

        }
    }
}
